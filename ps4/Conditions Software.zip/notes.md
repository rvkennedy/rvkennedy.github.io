Required npm installs:
forever
forever-monitor
mongodb
mongojs
winston
ftp

For Windows at least, "spawn mongoexport" gives an error - need mongo bin in path

ERROR reporting
--------------

In the "UNIX Philosophy", it's recommended that the default output when there are no errors is nothing. So it would be good to disable "information" messages by default. But piping them to the "error" and "info" logs is fine.

Given that the logs are JSON, it would be good to give them structure, so that if a run fails, all its messages can be identified easily.

Consider throwing exceptions, and using error callbacks, as there are a lot of places where you check for errors, report them if found, then continue as though the erroneous code had worked correctly. This can lead to problems processing invalid data, and cause errors to stack up where only the first error is really of value.

[https://www.joyent.com/developers/node/design/errors](https://www.joyent.com/developers/node/design/errors)

You have a lot of anonymous functions that don't check for "err" before trying to use the other parameter. If there's an error, you want to check for it here, e.g.:

    data_sources.find(function(err, docs) {
        if(err)
            console.log('connectToDB: '+err);
        else if(docs) {
            datasource = docs;
            loadDataSources(docs);
        }
    });

